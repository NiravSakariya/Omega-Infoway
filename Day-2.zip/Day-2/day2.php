<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

        // day 2 PHP
        /*
            Delimeter
            Operators
            Variables
            Statement
            Loops 
            https://github.com/NiravSakariya/Omega-Infoway.git
        */

        echo "demo";

        $test = "test1";
        $Test = "test2";

        echo $test;
        echo $Test;
        echo "<hr>";

        $a = 5;
        $b = 10;

        $c = $a + $b;

        echo $c;

        echo "<hr>";

        $int = 10;

        var_dump($int);

        echo "<hr>";

        $str = 'Nirav';
        var_dump($str);
        echo "<hr>";

        $flt = 18.455;
        var_dump($flt);
        echo "<hr>";
        
        $bl = TRUE;
        var_dump($bl);
        echo "<hr>";

        $arr = ([4,'67','12']);
        var_dump($arr);
        echo "<hr>";

        $arr2 = (['demo','test','test21']);
        var_dump($arr2);
        echo "<hr>";
        
        $bl = NULL;
        var_dump($bl);
        echo "<hr>";

        $sent = "PHP";

        echo "Learning $sent";

        echo "<hr>";

        $sent = "PHP Language";

        echo "Learning".$sent."!";

        echo "<hr>";
    ?>
    <hr>

    <?php

        if(4>3){
            echo "4 is greater than 3";
        }

        echo "<hr>";

        $a = 50;

        if($a>30){
            echo "greater";
        }else{
            echo "less than 50";
        }

        echo "<hr>";

        $b = 8;

        if($b>8)
        {
            echo "b is greater than 8";
        }elseif($b >= 8){
            echo "b is equal to 8 ";
        }else{
            echo "small";
        }

        echo "<hr>";
        
        // Sorthand
        $x = 30;
        $c = $x > 10 ? "ok" : "error";

        echo $c;



    ?>

</body>
</html>