<?php

require_once("navigation.php");
require_once("content.php");

?>